<?php 
   
  /* public function explode_value($string)
    {
        $getsep_string = explode(",",$string);

        $keys = '';
        $values = '';
        foreach ($getsep_string as $key => $value) 
        {
            $val =  explode("->",$value);
            $keys .= "$val[0],";
            $values .= "$val[1],";
        }
         
        $data = collect(["keys" => rtrim( $keys,','), "values" =>rtrim($values,',')]);
         return $data;
    }*/
?>
<style type="text/css">
   .colerclass{
      color: #317eeb;
   }
   .menustyle{
      margin: 10px;
   }
</style>
<!-- Start content -->
<div class="content">
   <div class="container-fluid">
      <!-- Page-Title -->
      <div class="row">
         <div class="col-sm-12">
            <h4 class="pull-left page-title">Edit Product</h4>
            <ol class="breadcrumb pull-right">
               <li><a href="{{ URL::to('home') }}">Home</a></li>
               <li class="active">Edit Product</li>
            </ol>
         </div>
      </div>
      <form  action="{{ URL::to('add/product')}}" method="POST" id="FormValidation" enctype="multipart/form-data">
         @csrf
         <div class="row" id="example-basic">
            <div class="col-md-12">
               <div class="card">
                  <div class="card-body">
                     <input type="hidden" name="ids" id="ids" value="{{ $editdata->id ?? '' }}">
                     <div class="row">
                        <div class="col-md-12">
                        <h3 style="color: red;">Basic Informations </h3>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Product Name : <font color="red">*</font></label>
                              <input  type="text" id="product_name" name="product_name" class="form-control" required="" value="{{ $editdata->product_name ?? ''}}" aria-required="true" placeholder="" autocomplete="off"> 
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Product Price : <font color="red">*</font></label>
                              <input  type="text" id="product_price" name="product_price" class="form-control" required="" value="{{ $editdata->product_price ?? ''}}" aria-required="true" placeholder="" maxlength="9"> 
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $brand = DB::table('brand')->get(); ?>
                              <label class="control-label">Brand : <font color="red">*</font></label>
                              <select class="form-control" id="brand_id" name="brand_id" required="">
                                <!--  @if($productData->brand_name ?? '')
                                 <option> {{ $productData->category_name }} </option>
                                 @endif -->
                                 <option value=""> Choose Brand</option>
                                 @foreach($brand as $value)
                                  <option value="{{ $value->id }}" {{ ($value->id == $editdata->brand_id) ? "selected" : "" }}>{{ $value->brand_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $category = DB::table('category')->get(); ?>
                              <label class="control-label">Category : <font color="red">*</font></label>
                              <select class="form-control" id="category_id" name="category_id" required="">
                                <!--  @if($productData->brand_name ?? '')
                                 <option> {{ $productData->category_name }} </option>
                                 @endif -->
                                 <option value=""> Choose Category</option>
                                 @foreach($category as $value)
                                 <option value="{{ $value->id }}" {{ ($value->id == $editdata->category_id) ? "selected" : "" }}>{{ $value->category_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>

                        <div class="col-md-6">
                           <div class="form-group">
                              <?php $branch = DB::table('branches')->get(); ?>
                              <label class="control-label">Branch : <font color="red">*</font></label>
                              <select class="form-control" id="branch_id" name="branch_id" required="">
                                <!--  @if($productData->brand_name ?? '')
                                 <option> {{ $productData->category_name }} </option>
                                 @endif -->
                                 <option value=""> Choose Branch</option>
                                 @foreach($branch as $value)
                                 <option value="{{ $value->id }}" {{ ($value->id == $editdata->branch_id) ? "selected" : "" }}>{{ $value->branch_name }}</option>
                                 @endforeach
                              </select>
                           </div>
                        </div>
                        
                        <div class="col-md-6">
                           <div class="form-group">  
                              <label class="control-label">Inventory <font color="red">*</font></label>
                              <input type="text" id="inventory" name="inventory" class="form-control" required="" aria-required="true" value="{{ $editdata->inventory ?? ''}}" placeholder=""> 
                           </div>
                        </div>

                        <hr>
                        <div class="col-md-12">
                           <h3 style="color: red;">Image Section </h3>
                        </div>

                        <?php $imgdata = explode(',', $editdata->image); ?>

                        @foreach($imgdata as $img)
                        <div class="col-md-3" style="border: 1px solid">
                           <div class="form-group"> 
                              <img src="http://localhost/wmc_admin/public/product_image/{{ $img }}" alt="Girl in a jacket" width="70" height="70">
                              <input type="file" name="" value="{{ $img }}">
                           </div>
                        </div>
                        @endforeach
                     </div>

                     <hr>
                     <h3 style="color: red;">Main Specification</h3>

                           <div class="row" id="main_speci_id">
                              <?php                                  
                                 $getsep_string = explode(",",$editdata->basic_speci);

                                 $keys = '';
                                 $values = '';
                                foreach ($getsep_string as $key => $value) 
                                {
                                    $val =  explode("->",$value);
                                    $keys .= "$val[0],";
                                    $values .= "$val[1],";
                                }
                                 
                                 $data = collect(["keys" => rtrim($keys,','), "values" =>rtrim($values,',')]);
                                 $myArray = explode(',', $data['keys']);
                                 $myArrayValues = explode(',', $data['values']);
                              ?>                              
                                 <div class="col-md-5">
                                    @foreach($myArray as $value)
                                    <div class="form-group">
                                       <?php $basic_speci = DB::table('basic_specification')->get(); ?>
                                       <select class="form-control" id="main_specification" name="main_specification[]">
                                          <?php $edit = DB::table('basic_specification')->where('id', $value)->first(); ?>
                                          <option value="{{ $edit->id }}">{{ $edit->main_specification }}</option>
                                          @foreach($basic_speci as $value)
                                          <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                          @endforeach
                                       </select>
                                    </div>
                                     @endforeach
                                 </div>
                              <div class="col-md-5">
                                 @foreach($myArrayValues as $value)
                                 <div class="form-group">  
                                    <input  type="text" id="basic_speci_value" name="basic_speci_value[]" class="form-control" required="" aria-required="true" value="{{ $value }}"> 
                                 </div>
                                 @endforeach
                              </div>
                              
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addCF btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>

                        <hr>
                        <h3 style="color: red;">Engine Specification</h3>                    
                           <div class="row" id="engine_section">
                              <?php                                  
                                 $getsep_string = explode(",",$editdata->engine);

                                 $keys = '';
                                 $values = '';
                                foreach ($getsep_string as $key => $value) 
                                {
                                    $val =  explode("->",$value);
                                    $keys .= "$val[0],";
                                    $values .= "$val[1],";
                                }
                                 
                                 $data = collect(["keys" => rtrim($keys,','), "values" =>rtrim($values,',')]);
                                 $myArray = explode(',', $data['keys']);
                                 $myArrayValues = explode(',', $data['values']);
                              ?>

                              <div class="col-md-5">
                                 @foreach($myArray as $value)
                                 <div class="form-group">
                                    <?php $engine = DB::table('engine')->get(); ?>
                                    <select class="form-control" id="engine" name="engine[]" >
                                     
                                       <?php $edit = DB::table('engine')->where('id', $value)->first(); ?>
                                          <option value="{{ $edit->id }}">{{ $edit->engine_key_name }}</option>
                                       @foreach($engine as $value)
                                       <option value="{{ $value->id }}">{{ $value->engine_key_name }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                 @endforeach
                              </div>

                              <div class="col-md-5">
                                 @foreach($myArrayValues as $value)
                                 <div class="form-group">  
                                    <input  type="text" id="engine_value_name" name="engine_value_name[]" class="form-control" required="" aria-required="true" value="{{ $value }}"> 
                                 </div>
                                 @endforeach
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addENG btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        

                        <hr>
                           <h3 style="color: red;">Chasis Specification</h3> 

                           <div class="row" id="chasis_section">
                              <?php                                  
                                 $getsep_string = explode(",",$editdata->chasis);

                                 $keys = '';
                                 $values = '';
                                foreach ($getsep_string as $key => $value) 
                                {
                                    $val =  explode("->",$value);
                                    $keys .= "$val[0],";
                                    $values .= "$val[1],";
                                }
                                 
                                 $data = collect(["keys" => rtrim($keys,','), "values" =>rtrim($values,',')]);
                                 $myArray = explode(',', $data['keys']);
                                 $myArrayValues = explode(',', $data['values']);
                              ?>
                              <div class="col-md-5">
                                 @foreach($myArray as $value)
                                 <div class="form-group">
                                    <?php $chasis = DB::table('chasis')->get(); ?>
                                    <select class="form-control" id="chasis" name="chasis[]" required="">
                                       <?php $edit = DB::table('chasis')->where('id', $value)->first(); ?>
                                          <option value="{{ $edit->id }}">{{ $edit->chasis_key_name }}</option>
                                       @foreach($chasis as $value)
                                       <option value="{{ $value->id }}">{{ $value->chasis_key_name }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                 @endforeach
                              </div>

                              <div class="col-md-5">
                                 @foreach($myArrayValues as $value)
                                 <div class="form-group">  
                                    <input  type="text" id="chasis_value_name" name="chasis_value_name[]" class="form-control" required="" aria-required="true" value="{{ $value }}"> 
                                 </div>
                                 @endforeach
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addCHA btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                        <hr>

                           <h3 style="color: red;">Super Comfortable Specification</h3>
                           <div class="row" id="sprconf_section">
                              <?php                                  
                                 $getsep_string = explode(",",$editdata->super_comfortable);

                                 $keys = '';
                                 $values = '';
                                foreach ($getsep_string as $key => $value) 
                                {
                                    $val =  explode("->",$value);
                                    $keys .= "$val[0],";
                                    $values .= "$val[1],";
                                }
                                 
                                 $data = collect(["keys" => rtrim($keys,','), "values" =>rtrim($values,',')]);
                                 $myArray = explode(',', $data['keys']);
                                 $myArrayValues = explode(',', $data['values']);

                                /* print_r($myArrayValues); die;*/
                              ?>
                              <div class="col-md-5">
                                 @foreach($myArray as $value)
                                 <div class="form-group">
                                    <?php $super_comfortable = DB::table('super_comfortable')->get(); ?>
                                    <select class="form-control" id="super_comfortable" name="super_comfortable[]" required="">
                                       <?php $edit = DB::table('super_comfortable')->where('id', $value)->first(); ?>
                                          <option value="{{ $edit->id }}">{{ $edit->main_specification }}</option>
                                       <option value="">Choose Chasis</option>
                                       @foreach($super_comfortable as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                 @endforeach
                              </div>

                              <div class="col-md-5">
                                 @foreach($myArrayValues as $value)
                                 <div class="form-group">  
                                    <input  type="text" id="super_comfortable_value" name="super_comfortable_value[]" class="form-control" required="" aria-required="true" value="{{ $value }}"> 
                                 @endforeach
                                 </div>
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addSPRCON btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                       

                     <hr>
                        <h3 style="color: red;">Multidimensional Security Specification</h3>
                           <div class="row" id="multi_secuarty_id">
                              <?php                                  
                                 $getsep_string = explode(",",$editdata->multi_secuarity);

                                 $keys = '';
                                 $values = '';
                                foreach ($getsep_string as $key => $value) 
                                {
                                    $val =  explode("->",$value);
                                    $keys .= "$val[0],";
                                    $values .= "$val[1],";
                                }
                                 
                                 $data = collect(["keys" => rtrim($keys,','), "values" =>rtrim($values,',')]);
                                 $myArray = explode(',', $data['keys']);
                                 $myArrayValues = explode(',', $data['values']);

                                 /*print_r($myArray); die;*/
                              ?>
                              <div class="col-md-5">
                                 @foreach($myArray as $value)
                                 <div class="form-group">
                                    <?php $multidimensional_security = DB::table('multidimensional_security')->get(); ?>
                                    <select class="form-control" id="multi_secuarity" name="multi_secuarity[]" required="">
                                       <?php $edit = DB::table('multidimensional_security')->where('id', $value)->first(); ?>
                                          <option value="{{ $edit->id }}">{{ $edit->main_specification }}</option>
                                       @foreach($multidimensional_security as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                 @endforeach
                              </div>

                              <div class="col-md-5">
                                 @foreach($myArrayValues as $value)
                                 <div class="form-group">  
                                    <input  type="text" id="multi_secuarity_value" name="multi_secuarity_value[]" class="form-control" required="" aria-required="true" value="{{ $value }}"> 
                                 </div>
                                 @endforeach
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addMLTSCR btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                       
                     <hr>
                        <h3 style="color: red;">Entertainment Specification</h3>
                           <div class="row" id="entertainment_id">
                              <?php                                  
                                 $getsep_string = explode(",",$editdata->entertainment);

                                 $keys = '';
                                 $values = '';
                                foreach ($getsep_string as $key => $value) 
                                {
                                    $val =  explode("->",$value);
                                    $keys .= "$val[0],";
                                    $values .= "$val[1],";
                                }
                                 
                                 $data = collect(["keys" => rtrim($keys,','), "values" =>rtrim($values,',')]);
                                 $myArray = explode(',', $data['keys']);
                                 $myArrayValues = explode(',', $data['values']);

                                 /*print_r($myArray); die;*/
                              ?>

                              <div class="col-md-5">
                                 @foreach($myArray as $value)
                                 <div class="form-group">
                                    <?php $entertainment = DB::table('entertainment')->get(); ?>
                                    <select class="form-control" id="entertainment" name="entertainment[]" required="">
                                       <?php $edit = DB::table('entertainment')->where('id', $value)->first(); ?>
                                          <option value="{{ $edit->id }}">{{ $edit->main_specification }}</option>
                                       @foreach($entertainment as $value)
                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>
                                       @endforeach
                                    </select>
                                 </div>
                                  @endforeach
                              </div>

                              <div class="col-md-5">
                                 @foreach($myArrayValues as $value)
                                 <div class="form-group">  
                                    <input  type="text" id="entertainment_value" name="entertainment_value[]" class="form-control" required="" aria-required="true" value="{{ $value }}"> 
                                 </div>
                                 @endforeach
                              </div>
                              <div class="col-md-2">
                                 <div class="form-group"> 
                                    <a href="javascript:void(0);"class="addENTMNT btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add</a>
                                 </div>
                              </div>
                           </div>
                                                               
                     <div class="modal-footer">
                        <button type="submit" id="submitbtn" class="btn btn-primary">Submit</button>
                     </div>
                  </div>
                  <!-- End card-body -->
               </div>
               <!-- End card -->
         <!-- End row -->
      </form>
      <!-- Form End -->
   </div>
   <!-- container -->
</div>

<!-- Main Specication Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addCF").click(function(_val)
      {
         $("#main_speci_id").append('<div class="col-md-5"><div class="form-group">                                    <?php $basic_speci = DB::table('basic_specification')->get(); ?>                                    <select class="form-control" id="main_specification" name="main_specification[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value=""> Choose Basic Specification</option>                                      @foreach($basic_speci as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                    <input  type="text" id="basic_speci_value" name="basic_speci_value[]" class="form-control" required="" aria-required="true" placeholder="">                                 </div>                              </div>                              <div class="col-md-2">                                 <div class="form-group">                                     <a href="javascript:void(0);" class="remCF btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#main_speci_id").on('click','.remCF',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Engine Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addENG").click(function(_val)
      {
         $("#engine_section").append('<div class="col-md-5"><div class="form-group">                                    <?php $engine = DB::table('engine')->get(); ?>
                                    <select class="form-control" id="engine" name="engine[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value="">Choose Engine</option>                                       @foreach($engine as $value)                                       <option value="{{ $value->id }}">{{ $value->engine_key_name }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="engine_value_name" name="engine_value_name[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                 <div class="form-group"> <a href="javascript:void(0);" class="removeENG btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#engine_section").on('click','.removeENG',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Chahis Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addCHA").click(function(_val)
      {
         $("#chasis_section").append('<div class="col-md-5">                                 <div class="form-group">                                    <?php $chasis = DB::table('chasis')->get(); ?>
                                    <select class="form-control" id="chasis" name="chasis[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value="">Choose Chasis</option>                                       @foreach($chasis as $value)                                       <option value="{{ $value->id }}">{{ $value->chasis_key_name }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                             <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="chasis_value_name" name="chasis_value_name[]" class="form-control" required="" aria-required="true" placeholder="">                                 </div>                              </div>                              <div class="col-md-2"> <a href="javascript:void(0);" class="removeCHA btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#chasis_section").on('click','.removeCHA',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Super Confurtable Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addSPRCON").click(function(_val)
      {
         $("#sprconf_section").append('<div class="col-md-5">                                 <div class="form-group">                                    <?php $super_comfortable = DB::table('super_comfortable')->get(); ?>
                                    <select class="form-control" id="super_comfortable" name="super_comfortable[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value=""> Choose Super Comfortable</option>                                       @foreach($super_comfortable as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="super_comfortable_value" name="super_comfortable_value[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                <div class="form-group"> <a href="javascript:void(0);" class="removeSPRCON btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#sprconf_section").on('click','.removeSPRCON',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- MLTSERT Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addMLTSCR").click(function(_val)
      {
         $("#multi_secuarty_id").append('<div class="col-md-5">                                 <div class="form-group">                                    <?php $multidimensional_security = DB::table('multidimensional_security')->get(); ?>
                                    <select class="form-control" id="multi_secuarity" name="multi_secuarity[]" required="">                                      <!--  @if($productData->brand_name ?? '')                                       <option> {{ $productData->category_name }} </option>                                       @endif -->                                       <option value=""> Choose Multidimensional Security</option>                                       @foreach($multidimensional_security as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="multi_secuarity_value" name="multi_secuarity_value[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                <div class="form-group"> <a href="javascript:void(0);" class="removeMLTSCR btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#multi_secuarty_id").on('click','.removeMLTSCR',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

<!-- Entertainment Script -->
<script type="text/javascript">
   $(document).ready(function()
   {
      $(".addENTMNT").click(function(_val)
      {
         $("#entertainment_id").append('<div class="col-md-5">                                <div class="form-group">                                    <?php $entertainment = DB::table('entertainment')->get(); ?>
                                    <select class="form-control" id="entertainment" name="entertainment[]" required="">                                       <option value=""> Choose Entertainment</option>                                       @foreach($entertainment as $value)                                       <option value="{{ $value->id }}">{{ $value->main_specification }}</option>                                       @endforeach                                    </select>                                 </div>                              </div>                              <div class="col-md-5">                                 <div class="form-group">                                      <input  type="text" id="entertainment_value" name="entertainment_value[]" class="form-control" required="" aria-required="true" placeholder="">                                  </div>                              </div>                              <div class="col-md-2">                                <div class="form-group"> <a href="javascript:void(0);" class="removeENTMNT btn btn-danger"><i class="fa fa-times" aria-hidden="true"></i> Remove</a>                                 </div>                              </div>');
      });

         $("#entertainment_id").on('click','.removeENTMNT',function()
         {
            $(this).parent().parent().remove();
         });
   });
</script>

